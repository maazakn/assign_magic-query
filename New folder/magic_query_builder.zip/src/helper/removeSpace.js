const removeSpace = inpStr => inpStr.replace(/\s+/g, ' ').trim();

module.exports = removeSpace;
