const getValue = str => str.split('=')[1];

module.exports = getValue;
